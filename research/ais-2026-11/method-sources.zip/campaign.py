"""Collect separate hourly AIS recordings for one bounded validation campaign."""
import argparse
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import random
import sys
import time

WORKSPACE = Path(__file__).resolve().parents[2]
PROJECT = Path(__file__).resolve().parent / 'f28-baseline'
PREVIOUS = Path('C:/Users/Rozz/Documents/Codex/2026-10-28/ang/outputs/uav-maritime-twin-windows')
BASELINE_CAPTURE = PROJECT / 'data/ais/captures/621a8559a44d406a8e617cee31a65e04/capture.json'
CAMPAIGN = Path(__file__).parent / 'campaign'
STATUS = WORKSPACE / 'outputs/延长AIS观测状态.json'
HKT = timezone(timedelta(hours=8))

sys.path.insert(0, str(PROJECT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from src.ais_data import collect, load_key
from src.ais_replay import build_capture, replace_json
from src.workspace_catalog import catalog_lock


def now():
    return datetime.now(HKT)


def qualify_slot(slot):
    departure = datetime.fromisoformat(slot['fixed_departure_hkt']).timestamp()
    for record in slot['attempts']:
        if record['status'] != 'captured':
            continue
        directory = CAMPAIGN / 'data/ais/captures' / record['capture_id']
        try:
            bundle = build_capture(directory)
        except (OSError, ValueError, KeyError, TypeError) as error:
            slot.update(status='unusable_data', error=str(error))
            continue
        slot.update(capture_id=directory.name, capture_status=bundle['capture_status'],
                    valid_positions=bundle['valid_position_count'], vessels=bundle['vessel_count'],
                    observation_start_unix=bundle['start'], observation_end_unix=bundle['end'])
        if bundle['start'] is not None and bundle['start'] <= departure < bundle['end']:
            slot['status'] = 'candidate'
            slot.pop('error', None)
            return
        slot['status'] = 'unusable_data'


def collect_campaign(start, hours):
    if not 1 <= hours <= 168 or start.utcoffset() is None:
        raise ValueError('Provide a timezone-aware start and 1–168 hours')
    start = start.astimezone(HKT)
    end = start + timedelta(hours=hours)
    journal_path = CAMPAIGN / 'journal.json'
    key = load_key(PREVIOUS)
    base = json.loads(BASELINE_CAPTURE.read_text(encoding='utf-8'))['config']
    journal = json.loads(journal_path.read_text(encoding='utf-8')) if journal_path.exists() else {
        'start_hkt': start.isoformat(), 'end_hkt': end.isoformat(), 'planned_hours': hours, 'slots': {},
    }
    if journal['start_hkt'] != start.isoformat() or hours > journal['planned_hours']:
        raise ValueError('Existing campaign must keep its original start and may only be shortened')
    if any(int(slot) > hours for slot in journal['slots']):
        raise ValueError('The new duration excludes an already recorded slot')
    journal.update(end_hkt=end.isoformat(), planned_hours=hours)

    previous = json.loads(STATUS.read_text(encoding='utf-8')) if STATUS.exists() else {}
    resumed = previous.get('active_window') if previous.get('scheduled_start_hkt') == start.isoformat() else None

    def save(state, active=None):
        finished = list(journal['slots'].values())
        usable = [slot for slot in finished if slot['status'] == 'candidate']
        replace_json(journal_path, journal)
        replace_json(STATUS, {'state': state, 'updated_hkt': now().isoformat(),
            'scheduled_start_hkt': start.isoformat(), 'scheduled_end_hkt': end.isoformat(),
            'planned_hours': hours, 'completed_candidate_windows': len(usable),
            'completed_other_windows': len(finished) - len(usable),
            'candidate_windows_valid_position_messages': sum(s['valid_positions'] for s in usable),
            'active_window': active, 'process_id': __import__('os').getpid(),
            'scope': 'Collection status only. Candidate windows are audited separately for usable coverage and planning outcomes.'})

    save('waiting', resumed)
    while now() < start:
        time.sleep(min(15, max(0, (start - now()).total_seconds())))
    for i in range(hours):
        slot_key = str(i + 1)
        if slot_key in journal['slots']:
            continue
        slot_start = start + timedelta(hours=i)
        slot_end = slot_start + timedelta(hours=1)
        departure = slot_start + timedelta(minutes=15)
        if now() < slot_start:
            time.sleep((slot_start - now()).total_seconds())
        active = resumed if resumed and resumed['slot'] == i + 1 else {
            'slot': i + 1, 'start_hkt': slot_start.isoformat(), 'end_hkt': slot_end.isoformat(),
            'fixed_departure_hkt': departure.isoformat(), 'attempts': []}
        attempt = active.get('attempt_number', 0)
        if now() < slot_end - timedelta(seconds=45):
            while now() < slot_end - timedelta(seconds=45):
                attempt += 1
                config = dict(base, capture_seconds=max(1, int((slot_end - now()).total_seconds()) - 1))
                active['attempt_number'] = attempt
                save('collecting', active)
                directory, manifest = collect(CAMPAIGN, config, key)
                record = {'capture_id': directory.name, 'status': manifest['status'],
                          'subscription_confirmed': manifest['subscription_confirmed'],
                          'received_messages': manifest['message_count'], 'start_utc': manifest['started_at_utc'],
                          'end_utc': manifest['finished_at_utc'], 'raw_sha256': manifest['raw_sha256'],
                          'error': manifest.get('error')}
                active['attempts'].append(record)
                if manifest['status'] == 'captured':
                    break
                if 'provider_subscription_error' in (manifest.get('error') or ''):
                    active['status'] = 'subscription_rejected'
                    break
                save('retrying', active)
                delay = min(120, 5 * 2 ** min(attempt, 5)) + random.uniform(0, 3)
                time.sleep(max(0, min(delay, (slot_end - now()).total_seconds())))
        if active.get('status') != 'subscription_rejected':
            qualify_slot(active)
        active.setdefault('status', 'missed_or_interrupted')
        journal['slots'][slot_key] = active
        if active['status'] == 'subscription_rejected':
            save('subscription_rejected')
            return 2
        save('waiting')
    save('collection_finished')
    from evaluate import run_campaign_evaluation
    save('evaluating')
    run_campaign_evaluation(journal)
    save('evaluation_finished')
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--start', type=datetime.fromisoformat, required=True)
    parser.add_argument('--hours', type=int, default=48)
    args = parser.parse_args()
    with catalog_lock(CAMPAIGN, timeout=1):
        raise SystemExit(collect_campaign(args.start, args.hours))
