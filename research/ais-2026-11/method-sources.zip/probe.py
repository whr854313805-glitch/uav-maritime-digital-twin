"""Check the current subscription without changing the project default data."""
import json
from pathlib import Path
import sys

workspace = Path(__file__).resolve().parents[2]
project = workspace / 'outputs/uav-maritime-digital-twin'
previous = Path('C:/Users/Rozz/Documents/Codex/2026-10-28/ang/outputs/uav-maritime-twin-windows')
sys.path.insert(0, str(project))
from src.ais_data import collect, load_key
from src.ais_replay import build_capture, replace_json

baseline = project / 'data/ais/captures/621a8559a44d406a8e617cee31a65e04/capture.json'
config = json.loads(baseline.read_text(encoding='utf-8'))['config']
config['capture_seconds'] = 45
directory, manifest = collect(Path(__file__).parent / 'connection-probe', config, load_key(previous))
report = {'capture_id': directory.name, 'status': manifest['status'],
          'subscription_confirmed': manifest['subscription_confirmed'],
          'messages': manifest['message_count'], 'error': manifest.get('error')}
if manifest['status'] == 'captured':
    bundle = build_capture(directory)
    report.update(valid_positions=bundle['valid_position_count'], vessels=bundle['vessel_count'])
replace_json(Path(__file__).parent / 'connection-probe/status.json', report)
print(json.dumps(report, ensure_ascii=True))
sys.exit(0 if manifest['status'] == 'captured' else 1)
