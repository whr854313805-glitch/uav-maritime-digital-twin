from pathlib import Path
import json,re,time
from playwright.sync_api import sync_playwright
def read(f): return json.loads(Path(f).read_text(encoding='utf-8-sig'))
meta=read('.local/controlled-demo-browser.json')
assert meta['launch_id']==read('.local/launcher-state.json')['launch_id']
state_file=Path('anylogic/visual_demo/state.json')
cases=[('Direct Flight','M2','The route clears'),('Same-Direction Detour','encounter_M1_same_direction','Same-direction traffic'),('Opposing Traffic','encounter_M1_opposing','159°'),('Start Blocked','encounter_M1_start_conflict','within 90 m'),('Building Avoidance','M4','35,335'),('Single Observation','encounter_M1_singleton','477995429')]
with sync_playwright() as pw:
    browser=pw.chromium.connect_over_cdp(f"http://127.0.0.1:{meta['debug_port']}")
    page=next(p for p in browser.contexts[0].pages if p.url.rstrip('/')==meta['url'])
    page.set_default_timeout(12000)
    page.locator('canvas[data-engine]:visible').last.wait_for()
    btn=page.locator('g.control[type=ControlButton]:visible')
    def click(name):btn.filter(has_text=re.compile('^'+re.escape(name)+'$')).first.click(delay=60)
    def visible():return page.locator('svg text:visible').all_text_contents()
    def check(needle):
        page.wait_for_function("v=>[...document.querySelectorAll('svg text')].some(e=>e.getBoundingClientRect().height && e.textContent.includes(v))",arg=needle)
        labels=visible()
        assert any(needle in line for line in labels),needle
        assert all(not re.search(r'[\u3400-\u9fff]',x) for x in labels),[x for x in labels if re.search(r'[\u3400-\u9fff]',x)]
        overflow=page.locator('svg text.shape-text:visible').evaluate_all("""els=>els.flatMap(e=>{const m=e.transform.baseVal.consolidate()?.matrix;if(!m||m.e<1070)return [];const b=e.getBBox();return m.e+b.x+b.width>1665?[e.textContent]:[]})""")
        assert not overflow,overflow
    assert page.locator('#control-panel-info-state').text_content()=='Running'
    for button,key,needle in cases:
        click(button)
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            try:s=read(state_file)
            except (OSError,ValueError):continue
            if s['key']==key and not s['busy']:break
            time.sleep(.1)
        assert s['key']==key and not s['busy']
        check(needle)
        print('PASS',button)
    for key in ('M1','M2','M3','M4'):
        button=next(v for v in btn.all_text_contents() if v.startswith(key+' '))
        click(button);check(button);check('Fixed task');print('PASS',key)
    click('2D View');check('Cruise start');check('Cruise end')
    click('3D View');click('Harbour View');check('Victoria Harbour landmarks');click('Reset Camera')
    click('Same-Direction Detour');check('The direct route passes too close')
    click('Closest Vessel')
    page.wait_for_timeout(1000)
    page.screenshot(path=str(Path('../../outputs/英文展示页.png').resolve()))
    print('PASS 2D, 3D, harbour view and screenshot.')
