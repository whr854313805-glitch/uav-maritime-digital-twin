"""Render the historical AIS replay for a widescreen presentation."""
import json
from collections import Counter
from datetime import datetime
from itertools import groupby
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


WORK = Path(__file__).resolve().parent
OUT = WORK.parents[2] / 'outputs'
report = json.loads((OUT / '延长AIS观测验证结果.json').read_text(encoding='utf-8'))
windows = sorted((w for w in report['windows'] if w['status'] == 'candidate'), key=lambda w: w['slot'])
routes = ['M1', 'M2', 'M3', 'M4']
pair = {(a['slot'], a['route']): a for a in report['attempts']}
assert len(pair) == len(windows) * len(routes) == len(report['attempts'])

def state(a):
    if a['evaluation'] == 'verified_start_rejection':
        assert a['failure_reason'] == 'start_ship_buffer'
        return 'refused'
    assert a['evaluation'] == 'planned_with_observed_ship_check' and a['independent_recheck_passed']
    return 'gap' if a['seconds_without_any_supported_ship'] > 0 else 'observed'

counts = Counter(map(state, pair.values()))
omitted = Counter(w['status'] for w in report['windows'])
refused, = (a for a in pair.values() if state(a) == 'refused')
stamp = datetime.fromisoformat(refused['departure_hkt'])
canvas = Image.new('RGB', (1920, 1080), '#FAFBF9')
draw = ImageDraw.Draw(canvas)
ink, muted, rule = '#17374A', '#445F6C', '#CCD9D9'
teal, amber, red = '#187562', '#855810', '#AC4D42'
fonts = {}

def label(x, y, s, size, color=ink, bold=False, align='lt'):
    key = (size, bold)
    if key not in fonts:
        font_file = 'msyhbd.ttc' if bold else 'msyh.ttc'
        fonts[key] = ImageFont.truetype(str(Path('C:/Windows/Fonts') / font_file), size)
    box = draw.textbbox((x, y), s, font=fonts[key], anchor=align)
    assert box[0] >= 0 and box[1] >= 0 and box[2] < 1920 and box[3] < 1080, (s, box)
    draw.text((x, y), s, anchor=align, font=fonts[key], fill=color)
    return box

def line(x1, y1, x2, y2, color=rule, width=2):
    draw.line((x1, y1, x2, y2), fill=color, width=width)

def symbol(x, y, result, radius=15):
    if result == 'observed':
        draw.ellipse((x-radius, y-radius, x+radius, y+radius), fill=teal)
        draw.line([(x-6,y),(x-2,y+4),(x+7,y-5)], fill='white', width=3)
    elif result == 'gap':
        draw.polygon([(x,y-radius-1),(x+radius+1,y),(x,y+radius+1),(x-radius-1,y)], fill=amber)
        line(x-5,y,x+5,y,'white',3)
    else:
        draw.rounded_rectangle((x-radius,y-radius,x+radius,y+radius),radius=4,fill=red)
        line(x-6,y-6,x+6,y+6,'white',3)
        line(x-6,y+6,x+6,y-6,'white',3)

label(76,48,'维港四条航线的 48 小时历史回放验证',54,bold=True)
label(79,133,'AISStream 船位记录    /    2026 年 11 月 18 日 17:12 至 20 日 17:12    /    香港时间',25,muted)
line(78,189,1842,189,ink,3)

valid_positions = sum(w['valid_positions'] for w in windows)
steps=[
    ('01','筛出可用时刻',[
        '每小时开始后第 15 分钟预定出发。',
        f'{len(report["windows"])} 个窗口中有 {len(windows)} 个覆盖出发时刻，',
        f'共 {valid_positions:,} 条有效船位记录。']),
    ('02','用相同条件跑四条航线',[
        '每个时刻各跑一次 M1、M2、M3、M4。',
        '沿用固定起终点和 15 米/秒的速度，',
        f'{len(windows)} 个时刻 × 4 条航线，共 {len(pair)} 次验证。']),
    ('03','用原始船位复核',[
        '把模拟航迹与同一时刻的已知船位对齐。',
        '检查船距 ≥ 90 米、建筑间距 ≥ 30 米，',
        '并核对起终点、地图边界和速度。'])]
for i,(n,title,lines) in enumerate(steps):
    left = [78,666,1265][i]
    if i:
        line(left-27,224,left-27,372)
    label(left,224,n,27,teal,True)
    label(left+56,217,title,35,bold=True)
    for j,s in enumerate(lines):
        box=label(left,280+38*j,s,25,muted)
        assert box[2] < [638,1238,1845][i]

line(78,402,1842,402)
label(78,431,'76 次验证，每个符号代表一次',39,bold=True)
label(80,497,'按出发时刻排列，每列同时验证四条航线。',24,muted)
width = 80
x0 = 286
mid = [x0+i*width for i in range(len(windows))]
dates = [datetime.fromisoformat(w['fixed_departure_hkt']) for w in windows]
for index_group in (list(g) for _,g in groupby(range(len(dates)), key=lambda i: dates[i].date())):
    i,j = index_group[0],index_group[-1]
    line(mid[i]-31,581,mid[j]+31,581)
    label((mid[i]+mid[j])//2,544,f'{dates[i].month} 月 {dates[i].day} 日',24,muted,True,'mt')
    if i:
        line(mid[i]-40,591,mid[i]-40,842,'#B7C7C8')
for x,t in zip(mid,dates):
    label(x,597,t.strftime('%H:%M'),21,muted,align='mt')
label(78,597,'航线',22,muted)
for i,route in enumerate(routes):
    y=658+55*i
    if i%2==0:
        draw.rounded_rectangle((78,y-22,1842,y+22),radius=8,fill='#EDF3F1')
    label(100,y,route,29,ink,True,'lm')
    for x,w in zip(mid,windows):
        symbol(x,y,state(pair[w['slot'],route]))
for x,c,caption in [
    (94,'observed',f'{counts["observed"]} 次通过 · 全程每个时刻都有可用船位'),
    (775,'gap',f'{counts["gap"]} 次通过 · 部分时间没有可用船位'),
    (1480,'refused',f'{counts["refused"]} 次拒飞 · 起点船距不足')]:
    symbol(x,887,c,14)
    label(x+29,887,caption,25,ink,True,'lm')

line(78,929,1842,929,ink)
label(78,950,f'唯一一次拒飞发生在 {stamp.month} 月 {stamp.day} 日 {stamp:%H:%M}。{refused["route"]} 起点离船 {refused["start_ship_distance_m"]:.2f} 米，低于 90 米，复核确认应当拒飞。',26,bold=True)
label(78,1007,f'覆盖范围  /  其余 {omitted["unusable_data"]} 个窗口的完整记录开始太晚，{omitted["missed_or_interrupted"]} 个错过或中断。船位缺口内的真实船距未知；本轮只能验证模型在已有观测下的表现。'.replace('；','。'),23,muted)
image_path=WORK/'48小时航线验证图解.png'
canvas.save(image_path, optimize=True)
canvas.resize((1200,675),Image.Resampling.LANCZOS).save(WORK/'figure-preview.png')
