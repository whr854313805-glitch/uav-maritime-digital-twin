"""Verify the exported workbook and the two publishable files before replacing the prior report."""
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from tempfile import NamedTemporaryFile
from xml.etree.ElementTree import tostring

from openpyxl import load_workbook
from PIL import Image

work = Path(__file__).resolve().parent
out = work.parents[2] / 'outputs'
folder = out / '维港48小时验证'
book = '76次航线验证结果.xlsx'
fig = '48小时航线验证图解.png'
prior = folder/book
old_hash = sha256(prior.read_bytes()).digest()
report = json.loads((out/'延长AIS观测验证结果.json').read_text(encoding='utf-8'))
for cached in [False, True]:
    old = load_workbook(prior,data_only=cached)
    new = load_workbook(work/book,data_only=cached)
    assert new.sheetnames == ['验证图解','时段对比','逐次明细']
    assert new.active.title == '验证图解'
    for name in ['时段对比','逐次明细']:
        a, b = old[name],new[name]
        assert a.calculate_dimension() == b.calculate_dimension()
        for row in a.iter_rows():
            for cell in row:
                other = b[cell.coordinate]
                assert cell.value == other.value, (name,cell.coordinate,cell.value,other.value)
                if not cached:
                    for k in ('number_format','font','fill','border','alignment','protection'):
                        cx,cy=getattr(cell,k),getattr(other,k)
                        if k!='number_format':
                            cx,cy=tostring(cx.to_tree()),tostring(cy.to_tree())
                        assert cx == cy, (name,cell.coordinate,k)
        assert a.freeze_panes == b.freeze_panes
        assert list(a.tables.keys()) == list(b.tables.keys())
        assert [str(r.sqref) for r in a.conditional_formatting] == [str(r.sqref) for r in b.conditional_formatting]
        for k in a.tables.keys():
            assert a.tables[k].ref == b.tables[k].ref
            assert a.tables[k].autoFilter.ref == b.tables[k].autoFilter.ref
    assert all(cell.data_type!='e' for sh in new for row in sh for cell in row)
    if cached:
        guide,detail=new.active,new['逐次明细']
        by_run={a['run_id']:a for a in report['attempts']}
        assert len(by_run)==76 and detail.max_row==82
        source_index={(a['route'],datetime.fromisoformat(a['departure_hkt']).replace(tzinfo=None)):a for a in by_run.values()}
        for r in range(7,83):
            a=by_run[detail.cell(r,14).value]
            assert detail.cell(r,2).value==a['route'] and detail.cell(r,1).value==datetime.fromisoformat(a['departure_hkt']).replace(tzinfo=None)
            for c,k in [(5,'minimum_observed_ship_distance_m'),(6,'minimum_building_envelope_clearance_m'),(9,'seconds_without_any_supported_ship'),(10,'start_ship_distance_m')]:
                number=detail.cell(r,c).value
                assert (number is None and a.get(k) is None) or abs(number-a[k])<1e-8
        for r in range(12,16):
            for c in range(2,21):
                a=source_index[(guide.cell(r,1).value,guide.cell(11,c).value)]
                expected='拒飞' if a['evaluation']=='verified_start_rejection' else '有缺口' if a['seconds_without_any_supported_ship']>0 else '通过'
                assert guide.cell(r,c).value == expected
        assert [guide[a].value for a in ('A17','G17','N17')]==[63,12,1]
    old.close()
    new.close()
with Image.open(work/fig) as img:
    assert img.size==(1920,1080)
    img.verify()
assert sha256(prior.read_bytes()).digest()==old_hash
for name in (fig,book):
    with NamedTemporaryFile(dir=folder,delete=False) as handle:
        temp=Path(handle.name)
    try:
        copyfile(work/name,temp)
        temp.replace(folder/name)
    finally:
        temp.unlink(missing_ok=True)
    assert sha256((folder/name).read_bytes()).digest()==sha256((work/name).read_bytes()).digest()
print('Verified all 76 cells against runs, original sheets and formats retained, 63/12/1; published XLSX and 1920x1080 PNG.')
