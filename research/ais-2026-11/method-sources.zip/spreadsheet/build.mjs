import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {Workbook, SpreadsheetFile} from '@oai/artifact-tool';

const work = path.dirname(fileURLToPath(import.meta.url));
const outputs = path.resolve(work, '../../../outputs');
const source = JSON.parse(await fs.readFile(path.join(outputs,'延长AIS观测验证结果.json'),'utf8'));
assert.equal(source.complete,true);
const eligible = source.windows.filter(w=>w.status==='candidate').sort((a,b)=>a.slot-b.slot);
const runs = [...source.attempts].sort((a,b)=>a.slot-b.slot || a.route.localeCompare(b.route));
const routes = ['M1','M2','M3','M4'];
const pairs = new Map(runs.map(r=>[r.slot+'-'+r.route,r]));
assert.equal(runs.length,76);
assert.equal(new Set(runs.map(r=>r.run_id)).size,76);
for(const w of eligible) for(const route of routes) assert.equal(pairs.get(w.slot+'-'+route).departure_hkt,w.fixed_departure_hkt);
const excelTime = hkt => (Date.parse(hkt)+8*3600000)/86400000+25569;

const wb = Workbook.create();
const guide = wb.worksheets.add('验证图解');
const ov = wb.worksheets.add('时段对比');
const detail = wb.worksheets.add('逐次明细');
const dark='#163B50', teal='#356A76', amber='#FFF0CF', red='#FCE4DF';
for(const sheet of [ov,detail]) sheet.showGridLines=false;
ov.tabColor=dark;
const write=(s,addr,v)=>{s.getRange(addr).values=[[v]];};
const cols=(s,widths)=>widths.forEach((width,i)=>s.getCell(0,i).format.columnWidth=width);
function base(s,addr) {
    const fmt=s.getRange(addr).format;
    fmt.font.name='Microsoft YaHei';
    fmt.font.size=10;
    fmt.font.color='#183847';
    fmt.verticalAlignment='center';
    fmt.rowHeight=18;
}
function title(s,text,end) {
    write(s,'A2',text);
    const r=s.getRange('A2:'+end+'2');
    r.format.font.bold=true; r.format.font.size=16; r.format.font.color=dark;
    r.format.rowHeight=32;
    r.format.borders={bottom:{style:'thin',color:teal}};
}
function header(s,addr){
    const f=s.getRange(addr).format; f.fill=dark;f.font.bold=true;f.font.color='#FFFFFF';
    f.horizontalAlignment='center';f.rowHeight=27;
    f.borders={insideVertical:{style:'thin',color:'#DBEAED'}};
}
function note(s,cell,text){write(s,cell,text);s.getRange(cell).format.font.color='#456471';}

const first=7,last=first+runs.length-1;
base(detail,'A1:P'+last);
cols(detail,[24,10,16,15,22,22,16,16,23,22,19,19,12,48,37,19]);
title(detail,'每次航线验证结果','P');
note(detail,'A3','来源为 AISStream 逐次报告《延长AIS观测验证结果.json》。所有时间均为香港时间（UTC+8）。');
note(detail,'A4','船距与建筑间距为水平距离。拒飞记录的飞行指标留空，起点船距单列。无船位时长为飞行期间没有任何可用船位的累计秒数。');
const fields=['出发时间（香港）','航线','复核结果','规划方式','最小已知船距（m）','最小建筑间距（m）','航程（m）','飞行时间（s）','无船位时长（s）','拒飞起点船距（m）','飞行中有观测船数','全程有观测船数','窗口编号','运行编号（run_id）','拒飞原因','计算耗时（s）'];
detail.getRange('A6:P6').values=[fields];
const matrix=runs.map(r=>{
    const success=r.evaluation==='planned_with_observed_ship_check';
    assert(success || (r.evaluation==='verified_start_rejection' && r.failure_reason==='start_ship_buffer'));
    const methods={validated_exact_straight_motion_no_search:'直飞',official_SST_plus_explicit_terminal_leg:'SST 绕行'};
    if(success) assert(r.independent_recheck_passed && methods[r.solver_method]);
    return [excelTime(r.departure_hkt),r.route,success?'航迹通过':'拒绝起飞',success?methods[r.solver_method]:null,
        r.minimum_observed_ship_distance_m??null,r.minimum_building_envelope_clearance_m??null,r.distance_m??null,r.flight_s??null,
        r.seconds_without_any_supported_ship??null,r.start_ship_distance_m??null,r.overlap_vessels??null,r.vessels_supported_throughout??null,
        r.slot,r.run_id,success?null:'起点船距低于 90 m，拒飞经复核',r.compute_elapsed_s];
});
detail.getRange('A'+first+':P'+last).values=matrix;
const nativeTable=detail.tables.add('A6:P'+last,true,'RouteRuns');
nativeTable.style='TableStyleLight9'; nativeTable.showFilterButton=true;
header(detail,'A6:P6');
const dateFormat='yyyy-mm-dd hh:mm';
detail.getRange('A'+first+':A'+last).setNumberFormat(dateFormat);
detail.getRange('B'+first+':B'+last).format.horizontalAlignment='center';
detail.getRange('E'+first+':J'+last).setNumberFormat('#,##0.000');
detail.getRange('P'+first+':P'+last).setNumberFormat('0.00');
detail.getRange('K'+first+':M'+last).setNumberFormat('0');
detail.getRange('C7:C'+last).conditionalFormats.add('containsText',{text:'拒绝起飞',format:{fill:red,font:{bold:true,color:'#8D3529'}}});
detail.getRange('I7:I'+last).conditionalFormats.add('cellIs',{operator:'greaterThan',formula:0,format:{fill:amber,font:{color:'#855319'}}});
detail.freezePanes.freezeRows(6);

base(ov,'A1:F30');
cols(ov,[25,16,16,16,16,25]);
title(ov,'维港四条航线的 48 小时验证','F');
const col = c => "'逐次明细'!$"+c+'$'+first+':$'+c+'$'+last;
write(ov,'A4','验证次数');write(ov,'C4','航迹通过');write(ov,'E4','拒绝起飞');
ov.getRange('B4').formulas=[['=COUNTA('+col('N')+')']];
ov.getRange('D4').formulas=[['=COUNTIFS('+col('C')+',C4)']];
ov.getRange('F4').formulas=[['=COUNTIFS('+col('C')+',E4)']];
const strip=ov.getRange('A4:F4').format;strip.fill='#E8F1F3';strip.font.bold=true;strip.rowHeight=26;strip.horizontalAlignment='center';
note(ov,'A6','2026 年 11 月 18–20 日，48 个采集窗口中有 19 个覆盖预定出发时刻。每个时刻各验证四条航线。');
note(ov,'A7','M1–M4 列显示通过复核的航线在飞行中的最小已知船距（米）。模型要求船距至少 90 米、建筑间距至少 30 米。');
note(ov,'A8','末列统计飞行途中出现船位缺口的航线数。缺口期间的实际船距未知，具体秒数见「逐次明细」。');
ov.getRange('A10:F10').values=[['出发时间（香港）',...routes,'有船位缺口的航线数']];
header(ov,'A10:F10');
for(const [i,w] of eligible.entries()){
    const row=11+i;
    write(ov,'A'+row,excelTime(w.fixed_departure_hkt));
    if(i%2===1)ov.getRange('A'+row+':F'+row).format.fill='#F1F6F7';
    for(const [j,L] of ['B','C','D','E'].entries()){
        const group=col('A')+',$A'+row+','+col('B')+','+L+'$10';
        ov.getRange(L+row).formulas=[['=IF(COUNTIFS('+group+')<>1,"核对记录",IF(COUNTIFS('+group+','+col('C')+',"拒绝起飞")=1,"拒绝起飞",SUMIFS('+col('E')+','+group+')))']];
        if(pairs.get(w.slot+'-'+routes[j]).evaluation==='verified_start_rejection')ov.getRange(L+row).format.horizontalAlignment='center';
    }
    ov.getRange('F'+row).formulas=[['=COUNTIFS('+col('A')+',$A'+row+','+col('I')+',">0")']];
}
ov.getRange('A11:A29').setNumberFormat(dateFormat);
ov.getRange('B11:E29').setNumberFormat('#,##0.00');
ov.getRange('B11:E29').conditionalFormats.add('containsText',{text:'拒绝起飞',format:{fill:red,font:{color:'#8D3529',bold:true}}});
ov.getRange('F11:F29').conditionalFormats.add('cellIs',{operator:'greaterThan',formula:0,format:{fill:amber,font:{color:'#855319'}}});

// The 19 columns are keyed by their full departure timestamps, including the date.
const gridEnd = 20;
const letter = n => String.fromCharCode(65+n);
const band = (range,caption,fill,color,bold=false,size=11,align='left') => {
    const r=guide.getRange(range);
    r.merge();
    r.values=[[caption]];
    r.format.fill=fill;
    r.format.font.color=color;
    r.format.font.bold=bold;
    r.format.font.size=size;
    r.format.horizontalAlignment=align;
};
guide.showGridLines=false;
guide.tabColor='#157568';
base(guide,'A1:T21');
cols(guide,[11,...eligible.map(()=>8)]);
band('A1:T1','维港四条航线怎样验证，结果如何？',dark,'#FFFFFF',true,17);
guide.getRange('A1:T1').format.rowHeight=38;
band('A2:T2','历史船位回放  /  2026 年 11 月 18 日 17:12 至 20 日 17:12  /  香港时间','#E8F1F3',dark);
const stages=[
    ['A4:F4','A5:F5','A6:F6','A7:F7','1   筛选出发时刻','每小时开始后 15 分钟为预定出发时刻。','48 个窗口中，19 个可用。','25 个完整记录开始太晚，4 个错过或中断。'],
    ['G4:M4','G5:M5','G6:M6','G7:M7','2   用同一时刻跑四条航线','每个可用时刻各跑一次 M1、M2、M3、M4。','沿用固定起终点，模型巡航速度为 15 米/秒。','19 个时刻 × 4 条航线，共 76 次。'],
    ['N4:T4','N5:T5','N6:T6','N7:T7','3   回到原始记录复核','按相同时间对齐模拟航迹与有记录的船位。','核对最小船距 ≥ 90 米、建筑间距 ≥ 30 米，','并检查起终点、边界和速度。拒飞则复查起点。'],
];
for(const [h,a,b,c,t,x,y,z] of stages){
    band(h,t,teal,'#FFFFFF',true,12);
    for(const [r,v] of [[a,x],[b,y],[c,z]]) band(r,v,'#F1F6F7',dark,false,10);
}
guide.getRange('A4:T4').format.rowHeight=26;
band('A9:T9','逐次结果   /   每格代表一条航线在一个出发时刻的验证',dark,'#FFFFFF',true,13);
guide.getRange('A9:T9').format.rowHeight=29;
write(guide,'A11','出发时刻');
const dates=Map.groupBy(eligible,w=>w.fixed_departure_hkt.slice(0,10));
let offset=1;
for(const [date,group] of dates){
    band(letter(offset)+'10:'+letter(offset+group.length-1)+'10',date.slice(5).replace('-',' 月 ')+' 日','#DCEAEC',dark,true,11,'center');
    offset+=group.length;
}
header(guide,'A11:T11');
guide.getRange('B11:T11').values=[eligible.map(w=>excelTime(w.fixed_departure_hkt))];
guide.getRange('B11:T11').setNumberFormat('hh:mm');
for(const [i,route] of routes.entries()){
    const row=12+i;
    write(guide,'A'+row,route);
    for(let j=1;j<gridEnd;j++){
        const group=col('A')+','+letter(j)+'$11,'+col('B')+',$A'+row;
        guide.getCell(row-1,j).formulas=[['=IF(COUNTIFS('+group+')<>1,"核对记录",IF(COUNTIFS('+group+','+col('C')+',"拒绝起飞")=1,"拒飞",IF(COUNTIFS('+group+','+col('C')+',"航迹通过")<>1,"核对记录",IF(COUNTIFS('+group+','+col('I')+',">0")=1,"有缺口","通过"))))']];
    }
}
const grid=guide.getRange('B12:T15');
grid.format.horizontalAlignment='center';
grid.format.font.bold=true;
grid.format.borders={insideVertical:{style:'thin',color:'#FFFFFF'},insideHorizontal:{style:'thin',color:'#FFFFFF'}};
for(const [text,fill,color] of [['通过','#D3EEE5','#165546'],['有缺口',amber,'#804B0B'],['拒飞',red,'#8D3529']]){
    grid.conditionalFormats.add('containsText',{text,format:{fill,font:{color,bold:true}}});
}
guide.getRange('A12:A15').format.font.bold=true;
guide.getRange('A12:A15').format.horizontalAlignment='center';
guide.getRange('A12:T15').format.rowHeight=27;
const legend=[
    ['A17','B17:F17','通过　全程每一刻都有可用船位','通过','#D3EEE5','#165546'],
    ['G17','H17:M17','有缺口　通过，但部分时间没有可用船位','有缺口',amber,'#804B0B'],
    ['N17','O17:T17','拒飞　起点船距低于门槛，复核确认','拒飞',red,'#8D3529'],
];
for(const [k,r,caption,state,fill,color] of legend){
    band(r,caption,fill,color,true,10);
    const c=guide.getRange(k);
    c.formulas=[['=COUNTIF($B$12:$T$15,"'+state+'")']];
    c.format.fill=fill;c.format.font.color=color;c.format.font.size=15;c.format.font.bold=true;c.format.horizontalAlignment='center';
}
guide.getRange('A17:T17').format.rowHeight=31;
const stop=runs.find(r=>r.evaluation==='verified_start_rejection');
band('A19:T19','唯一一次拒飞   /   '+stop.route+'，'+stop.departure_hkt.slice(5,10).replace('-',' 月 ')+' 日 '+stop.departure_hkt.slice(11,16)+'，起点离船 '+stop.start_ship_distance_m.toFixed(2)+' 米，低于模型的 90 米门槛。','#FAEFEC','#833C30',true);
band('A20:T20','结论范围   /   船距仅针对同一时刻能定位的船。缺口期间的真实船距未知，历史回放不能直接证明真实飞行安全。','#F1F6F7',dark);
band('A21:T21','查原始数字   /   「时段对比」列出各时刻最小已知船距。「逐次明细」可按航线和时间筛选，查看缺口秒数与运行编号。','#FFFFFF',dark);
guide.getRange('A19:T21').format.rowHeight=24;
wb.recalculate();
for(const [i,route] of routes.entries()){
    const statuses=guide.getRange('B'+(12+i)+':T'+(12+i)).values[0];
    const expected=eligible.map(w=>{
        const a=pairs.get(w.slot+'-'+route);
        return a.evaluation==='verified_start_rejection'?'拒飞':a.seconds_without_any_supported_ship>0?'有缺口':'通过';
    });
    assert.deepEqual(statuses,expected);
}
assert.deepEqual(legend.map(([k])=>guide.getRange(k).values[0][0]),[63,12,1]);
assert.equal(ov.getRange('B4').values[0][0],76);
assert.equal(ov.getRange('D4').values[0][0],75);
assert.equal(ov.getRange('F4').values[0][0],1);
for(const [i,w] of eligible.entries()) {
    const mapped=ov.getRange('B'+(11+i)+':F'+(11+i)).values[0];
    let gap=0;
    for(const [j,k] of routes.entries()){
        const a=pairs.get(w.slot+'-'+k);
        assert.equal(mapped[j],a.minimum_observed_ship_distance_m??'拒绝起飞');
        if(a.seconds_without_any_supported_ship>0)gap++;
    }
    assert.equal(mapped[4],gap);
}
const inspect=await wb.inspect({kind:'table',range:'时段对比!A10:F13',include:'values,formulas',tableMaxRows:4,tableMaxCols:6});
console.log(inspect.ndjson.slice(0,550));
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:20},summary:'formula error scan'});
console.log(errors.ndjson.slice(0,350));
for(const [sheet,range,name] of [[ov,'A1:F29','overview'],[detail,'A1:J12','detail'],[guide,'A1:T21','guide']]){
    const image=await wb.render({sheetName:sheet.name,range,scale:1,format:'png'});
    await fs.writeFile(path.join(work,name+'.png'),new Uint8Array(await image.arrayBuffer()));
}
const xlsx=await SpreadsheetFile.exportXlsx(wb);
await xlsx.save(path.join(work,'76次航线验证结果.xlsx'));
