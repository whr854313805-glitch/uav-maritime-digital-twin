from pathlib import Path
import json,math
from PIL import Image,ImageDraw,ImageFont
W=Path(__file__).resolve().parents[1]
P=W/'outputs/uav-maritime-digital-twin'
def load(f):return json.loads((P/f).read_text(encoding='utf-8-sig'))
s=load('anylogic/visual_demo/scenery.json'); w=load('anylogic/workbench/workspace.json')
S=2
def font(size,bold=False):
    return ImageFont.truetype('C:/Windows/Fonts/'+('segoeuib.ttf' if bold else 'segoeui.ttf'),size*S)
ink='#143348'; muted='#455e6d'; route='#7139ad'; link='#455866'; water='#dfedf4'; land='#f2f1e8'; shore='#a6b0a6'
out=Image.new('RGB',(1600*S,1000*S),'white'); draw=ImageDraw.Draw(out)
def text(x,y,t,size=18,color=ink,b=False):
    draw.text((x*S,y*S),t,font=font(size,b),fill=color,anchor='lt')
def line(a,b,color,width):
    draw.line((a[0]*S,a[1]*S,b[0]*S,b[1]*S),fill=color,width=width*S)
def point(d,xy,k):
    x,y=xy
    if k=='pier':
        rr=5*S; d.rectangle((x-rr,y-rr,x+rr,y+rr),fill='white',outline=ink,width=2*S)
    else:
        rr=6*S;d.ellipse((x-rr,y-rr,x+rr,y+rr),fill='#0d805c' if k=='start' else '#be4932',outline='white',width=2*S)
text(44,24,'Where the offshore routes begin and end',40,b=True)
text(46,82,'Victoria Harbour  |  Piers are geographic reference points. Each saved UAV route begins and ends at its offshore cruise points.',21,muted)
line((48,147),(102,147),route,4);text(114,135,'Planned cruise route',20)
for x in [373,387,401]:line((x,147),(x+8,147),link,2)
text(423,135,'Pier-to-point reference only',20)
for x,k,t in ((776,'pier','Pier'),(930,'start','Cruise start'),(1152,'end','Cruise end')):
    point(draw,(x*S,147*S),k);text(x+16,135,t,20)
titles=['Tsim Sha Tsui → Central','North Point → Hung Hom','Sai Wan Ho → Sam Ka Tsuen','East Tsim Sha Tsui → Lei Yue Mun']
def dashed(d,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1]; length=math.hypot(dx,dy)
    if not length:return
    for step in range(0,math.ceil(length),11*S):
        s0=step/length;s1=min(1,(step+7*S)/length)
        d.line((a[0]+s0*dx,a[1]+s0*dy,a[0]+s1*dx,a[1]+s1*dy),fill=link,width=3*S)
for i,title in enumerate(titles,1):
    key='M'+str(i); px=44+(i-1)%2*768;py=202+(i-1)//2*350
    text(px,py,key,23,route,True);text(px+58,py,title,23,b=True)
    sites=[x for x in w['sites'] if x['task']==key]
    rec=next(x for x in w['catalog'] if x['key']==key)
    r=load(Path('output')/rec['file']); flight=r['trajectory']['xy']
    assert r['status']=='planned' and all(math.dist(g['xy'],v)<1e-5 for g,v in zip(sites,(flight[0],flight[-1])))
    points=flight+[v['anchor_xy'] for v in sites]
    xmin,ymin=map(min,zip(*points));xmax,ymax=map(max,zip(*points))
    mw,mh=735,282
    scale=min((mw-120)/(xmax-xmin),(mh-72)/(ymax-ymin))
    ox=(xmin+xmax)/2;oy=(ymin+ymax)/2
    def proj(v):return (round((mw/2+(v[0]-ox)*scale)*S),round((mh/2-(v[1]-oy)*scale)*S))
    im=Image.new('RGB',(mw*S,mh*S),water);d=ImageDraw.Draw(im)
    for rings,color in [(s['land'],land),(s['coastlines'],shore)]:
        for ring in rings:
            pp=[proj(v) for v in ring]
            xs,ys=zip(*pp)
            if max(xs)<0 or min(xs)>mw*S or max(ys)<0 or min(ys)>mh*S:continue
            if color==land:d.polygon(pp,fill=color)
            else:d.line(pp,fill=color,width=S)
    for g in sites:dashed(d,proj(g['anchor_xy']),proj(g['xy']))
    xy=[proj(v) for v in flight]
    d.line(xy,fill=route,width=4*S)
    for k,site in zip(('start','end'),sites):
        point(d,proj(site['anchor_xy']),'pier');point(d,proj(site['xy']),k)
    metres=next(m for m in (2000,1000,500,250,100,50) if m*scale<111)
    sx=mw-46-metres*scale if i==3 else 10
    d.rectangle((sx*S,(mh-37)*S,(sx+23+metres*scale)*S,(mh-5)*S),fill='white')
    d.text(((sx+8)*S,(mh-35)*S),f'{metres:,} m',font=font(13),fill=ink)
    d.line(((sx+8)*S,(mh-12)*S,(sx+8+metres*scale)*S,(mh-12)*S),fill=ink,width=2*S)
    out.paste(im,(px*S,(py+42)*S))
line((44,918),(1547,918),'#cdd7db',1)
text(44,939,'Dashed links locate the cruise endpoints relative to the piers. Take-off, approach and landing fall outside the planning model.',19)
text(44,973,'Source: project M1–M4 saved trajectories, fixed research points and Hong Kong Lands Department shoreline snapshot. North up; each panel has its own scale.',14,muted)
out.resize((1920,1200),Image.Resampling.LANCZOS).save(W/'outputs/维港四条巡航线路示意图.png',dpi=(150,150))
