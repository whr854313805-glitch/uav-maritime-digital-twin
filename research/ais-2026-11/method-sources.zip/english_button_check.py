import json, re, time
from pathlib import Path
from playwright.sync_api import sync_playwright

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

meta=read('.local/controlled-demo-browser.json')
assert meta['launch_id']==read('.local/launcher-state.json')['launch_id']
host=Path('.local/jobs')/meta['launch_id']/'state.json'
view=Path('anylogic/visual_demo/state.json')
def until(fn):
    deadline=time.monotonic()+15
    while time.monotonic()<deadline:
        try:
            if fn():return
        except (ValueError,OSError):pass
        time.sleep(.12)
    raise AssertionError('UI state timeout')
with sync_playwright() as pw:
    browser=pw.chromium.connect_over_cdp(f"http://127.0.0.1:{meta['debug_port']}")
    page=next(p for p in browser.contexts[0].pages if p.url.rstrip('/')==meta['url'])
    page.set_default_timeout(8000)
    buttons=page.locator('g.control[type=ControlButton]:visible')
    def audit(name):
        labels=buttons.all_text_contents()
        clipped=buttons.evaluate_all("""els=>els.flatMap(e=>{const t=e.querySelector('text'),r=e.querySelector('rect');if(!t||!r)return [e.textContent]; const box=t.getBBox(); return (box.x<1 || box.x+box.width>Number(r.getAttribute('width'))+1)?[e.textContent]:[]})""")
        print(name, len(labels), 'clipped=',ascii(clipped),flush=True)
        assert not clipped and labels and all(label and not re.search(r'[\u3400-\u9fff]',label) for label in labels), ascii(labels)
        return labels
    def click(label):
        buttons.filter(has_text=re.compile('^'+re.escape(label)+'$')).first.click(delay=65)
        page.wait_for_timeout(450)
    original=read(view)
    assert len(audit('demo'))==22
    click('2D View')
    until(lambda:not read(view)['three_d'])
    click('3D View')
    until(lambda:read(view)['three_d'])
    canvas=page.locator('canvas[data-engine]:visible').last
    canvas.hover()
    page.keyboard.down('Control')
    try:page.mouse.wheel(0,-170)
    finally:page.keyboard.up('Control')
    page.wait_for_timeout(350)
    assert page.evaluate('window.__maritimeViewControls.factor')!=1
    click('Reset Camera')
    assert page.evaluate('window.__maritimeViewControls.factor')==1
    click('Direct Flight')
    until(lambda:read(view)['key']=='M2' and not read(view)['busy'])
    click('Demo / Workbench')
    until(lambda:not read(view)['demo'])
    assert len(audit('workbench'))==20
    boxes=page.locator('g.control[type=ControlCheckbox]:visible')
    assert boxes.all_text_contents()==['Buildings','Observed Positions','Interpolated Tracks','Vessel Positions','Research Sites']
    initial=read(host)['layers']['建筑背景']
    boxes.first.click();until(lambda:read(host)['layers']['建筑背景']!=initial)
    boxes.first.click();until(lambda:read(host)['layers']['建筑背景']==initial)
    click('Next Section')
    until(lambda:read(host)['section']=='原始记录')
    rows=[x for x in audit('raw records') if ' | Row ' in x]
    assert rows
    click(rows[0]);click('Next Page');click('Previous Page')
    click('Demo / Workbench')
    target={'encounter_M1_same_direction':'Same-Direction Detour','encounter_M1_opposing':'Opposing Traffic','encounter_M1_start_conflict':'Start Blocked','encounter_M1_singleton':'Single Observation'}.get(original['key'])
    if not target:target=next(x for x in buttons.all_text_contents() if x.startswith(original['key']+' '))
    click(target)
    until(lambda:read(view)['demo'] and read(view)['key']==original['key'] and not read(view)['busy'])
    print('PASS: view switches, zoom reset, route loading, layer toggles, raw observations, pagination and return to demo.')
