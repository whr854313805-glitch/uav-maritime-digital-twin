"""Evaluate fixed routes on separate AIS windows using the released evaluator."""
from collections import Counter
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import time

WORKSPACE = Path(__file__).resolve().parents[2]
PROJECT = Path(__file__).resolve().parent / 'f28-baseline'
PREVIOUS = Path('C:/Users/Rozz/Documents/Codex/2026-10-28/ang/outputs/uav-maritime-twin-windows')
STUDY = Path(__file__).parent / 'study'
EXPECTED = '3dfca00b27fe780e40dde19a0f19574cb2542dde'
HKT = timezone(timedelta(hours=8))

sys.path.insert(0, str(PROJECT))
from select_research_points import StaticSiteChecker
from src.ais_data import digest
from src.ais_replay import build_capture, replace_json
from src.ais_single_task import apply_reference_profile, load_environment, run_task
from src.project_config import load_config
from src.release_checks import verify_release
from src.safe_planning import validate_path
from verify_ais_encounters import raw_oracle


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def prepare_inputs():
    head = subprocess.check_output(['git', '-C', str(PROJECT), 'rev-parse', 'HEAD'], text=True).strip()
    if head != EXPECTED:
        raise ValueError('F28 analysis baseline changed. A comparable evaluation needs the original version.')
    release = verify_release(PROJECT)
    base = load_config(PROJECT / 'config.yaml')
    manifest_file = Path(base['data']['official_manifest'])
    manifest = read(PROJECT / manifest_file)
    catalog = {row['key']: row for row in read(PROJECT / 'anylogic/workbench/workspace.json')['catalog']}
    paths = {Path('config.yaml'), Path('config/parameter-sources.json'), manifest_file,
             Path(base['data']['buildings'])}
    paths.update(manifest_file.parent / 'raw' / name for name in manifest['raw_hashes']
                 if name.startswith('buildings_') and name.endswith('.geojson'))
    requests = {}
    for name in ('M1', 'M2', 'M3', 'M4'):
        item = catalog[name]
        file = PROJECT / 'output' / item['file']
        if digest(file) != item['sha256']:
            raise ValueError('Saved route identity mismatch: ' + name)
        request = read(file)['request']
        paths.add(Path(request['research_points']['selection_file']))
        requests[name] = request
    for path in paths:
        destination = STUDY / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(PROJECT / path, destination)
    return release['release_sha256'], requests


def ais_rows(bundle, checker, origin):
    for vessel in bundle['vessels']:
        for points in vessel['segments']:
            pairs = zip(points, points[1:]) if len(points) > 1 else [(points[0], points[0])]
            for a, b in pairs:
                yield (vessel['mmsi'], a['timestamp_unix_s'] - origin, b['timestamp_unix_s'] - origin,
                       checker.project([a['latitude'], a['longitude']]),
                       checker.project([b['latitude'], b['longitude']]))


def evaluate_one(source, bundle, request, departure, name):
    request = deepcopy(request)
    request['window_start_utc'] = departure.astimezone(timezone.utc).isoformat()
    started = time.monotonic()
    result = run_task(source, request, STUDY, publish=False)
    elapsed = time.monotonic() - started
    coverage = result.get('observation_coverage') or {}
    search = (result.get('planning') or {}).get('search') or {}
    data_check = result.get('data_check') or {}
    output = {'route': name, 'departure_hkt': departure.astimezone(HKT).isoformat(),
              'run_id': result['run_id'], 'capture_id': bundle['capture_id'],
              'raw_sha256': bundle['raw_sha256'], 'status': result['status'],
              'failure_reason': result.get('failure_reason'), 'evaluation': result['status'],
              'solver_method': search.get('method'), 'solver_seed': search.get('seed'),
              'solver_budget_s': search.get('solve_seconds'), 'compute_elapsed_s': elapsed,
              'available_record_span_s': data_check.get('available_seconds'),
              'overlap_vessels': len(coverage.get('task_participating_vessels', [])) if coverage else None,
              'vessels_supported_throughout': len(coverage.get('fully_supported_vessels', [])) if coverage else None,
              'seconds_without_any_supported_ship': coverage.get('seconds_without_any_supported_ship')}
    if result['status'] != 'planned' and result.get('failure_reason') != 'start_ship_buffer':
        return output
    cfg = apply_reference_profile(load_config(STUDY / 'config.yaml'), request)
    inputs, _ = load_environment(STUDY, cfg)
    checker = StaticSiteChecker(cfg, inputs)
    tolerance = cfg['planning']['clearance_tolerance_m']
    if result.get('failure_reason') == 'start_ship_buffer':
        point = checker.project(request['start'])
        offset = request['departure_offset_seconds']
        ship = raw_oracle({'xy': [point, point], 'times_s': [offset, offset]},
                          list(ais_rows(bundle, checker, data_check['window_start_unix_s'])))
        output['start_ship_distance_m'] = ship['minimum_distance_m']
        output['evaluation'] = ('verified_start_rejection' if ship['minimum_distance_m'] is not None
                                and ship['minimum_distance_m'] < request['buffer_m'] + tolerance else 'recheck_failed')
        return output
    tr = result['trajectory']
    a, b = checker.project(request['start']), checker.project(request['end'])
    direct_end = tr['departure_s'] + math.dist(a, b) / request['speed_mps']
    direct = {'xy': [a, b], 'times_s': [tr['departure_s'], direct_end]}
    rows = list(ais_rows(bundle, checker, result['window_start_unix_s']))
    ship = raw_oracle(tr, rows)
    minimum = ship['minimum_distance_m']
    geometry = validate_path(tr['path'], request['start'], request['end'], [], request['buffer_m'],
                             cfg, inputs['buildings']['buildings'], checker)
    error = max(abs(math.dist(x, y) / (tb - ta) - request['speed_mps'])
                for x, y, ta, tb in zip(tr['xy'], tr['xy'][1:], tr['times_s'], tr['times_s'][1:]))
    identity_ok = (result['capture_id'] == bundle['capture_id'] and result['raw_sha256'] == bundle['raw_sha256']
                   and result['request'] == request and math.dist(tr['xy'][0], a) <= 1e-6
                   and math.dist(tr['xy'][-1], b) <= 1e-6)
    passed = (identity_ok and geometry['geometry_valid'] and result['coverage_check']['valid'] and error <= 1e-6
              and (minimum is None or minimum >= request['buffer_m'] - tolerance))
    output.update(evaluation=('recheck_failed' if not passed else 'planned_no_ship_overlap' if minimum is None
                              else 'planned_with_observed_ship_check'),
                  independent_recheck_passed=passed, minimum_observed_ship_distance_m=minimum,
                  direct_reference_ship_distance_m=raw_oracle(direct, rows)['minimum_distance_m'],
                  direct_reference_distance_m=math.dist(a, b),
                  minimum_building_envelope_clearance_m=geometry['minimum_building_clearance_m'],
                  distance_m=tr['distance_m'], flight_s=tr['arrival_s'] - tr['departure_s'], maximum_speed_error_mps=error)
    return output


def evaluate_windows(slots, file):
    release, requests = prepare_inputs()
    results = read(file)['attempts'] if file.exists() else []
    report = {'baseline_git_commit': EXPECTED, 'baseline_release_sha256': release, 'windows': [], 'attempts': results,
              'complete': False, 'scope': 'Recorded vessel subset and original 2D parameters only. Timestamps were fixed before inspecting planning outcomes.'}
    for slot in slots:
        window = {k: v for k, v in slot.items() if k != 'source'}
        report['windows'].append(window)
        if slot['status'] != 'candidate':
            continue
        source = slot['source']
        bundle = build_capture(source)
        departure = datetime.fromisoformat(slot['fixed_departure_hkt'])
        window.update(capture_id=bundle['capture_id'], valid_positions=bundle['valid_position_count'],
                      vessels=bundle['vessel_count'], observation_span_s=bundle['end'] - bundle['start'],
                      longest_single_valid_segment_s=bundle['longest_contiguous_seconds'])
        for name, request in requests.items():
            if any(row['slot'] == slot['slot'] and row['route'] == name for row in results):
                continue
            result = evaluate_one(source, bundle, request, departure, name)
            result['slot'] = slot['slot']
            results.append(result)
            replace_json(file, report)
    report['outcomes'] = dict(Counter(row['evaluation'] for row in results))
    report['by_route'] = {name: dict(Counter(row['evaluation'] for row in results if row['route'] == name))
                          for name in requests}
    report['window_outcomes'] = dict(Counter(row['status'] for row in report['windows']))
    report['planned_route_window_pairs'] = len(slots) * len(requests)
    report['unevaluated_route_window_pairs'] = report['planned_route_window_pairs'] - len(results)
    report['by_day_and_period_hkt'] = {}
    for slot in report['windows']:
        local = datetime.fromisoformat(slot['fixed_departure_hkt']).astimezone(HKT)
        period = ('00:00–05:59' if local.hour < 6 else '06:00–11:59' if local.hour < 12 else
                  '12:00–17:59' if local.hour < 18 else '18:00–23:59')
        stratum = report['by_day_and_period_hkt'].setdefault(
            local.date().isoformat() + ' ' + period,
            {'is_weekend': local.weekday() >= 5, 'windows': Counter(), 'outcomes': Counter()})
        stratum['windows'][slot['status']] += 1
        stratum['outcomes'].update(row['evaluation'] for row in results if row['slot'] == slot['slot'])
    report['complete'] = True
    replace_json(file, report)
    return report


def run_campaign_evaluation(journal):
    slots = [dict(slot, source=Path(__file__).parent / 'campaign/data/ais/captures' / slot['capture_id'])
             if slot['status'] == 'candidate' else slot for slot in journal['slots'].values()]
    output = WORKSPACE / 'outputs/延长AIS观测验证结果.json'
    try:
        return evaluate_windows(slots, output)
    except Exception as error:
        report = read(output) if output.exists() else {}
        report.update(complete=False, evaluation_error=str(error))
        replace_json(output, report)
        status_file = WORKSPACE / 'outputs/延长AIS观测状态.json'
        status = read(status_file)
        status.update(state='evaluation_failed', updated_hkt=datetime.now(HKT).isoformat())
        replace_json(status_file, status)
        raise


if __name__ == '__main__':
    source = PREVIOUS / 'data/ais/captures/52960bb59b8542af8c1ea8f804fddc23'
    report = evaluate_windows([{'slot': 'historical_15min', 'status': 'candidate', 'source': source,
                                'fixed_departure_hkt': '2026-11-03T19:45:00+08:00'}],
                              WORKSPACE / 'outputs/额外AIS样本初步验证.json')
    print(json.dumps(report['outcomes'], ensure_ascii=True))
